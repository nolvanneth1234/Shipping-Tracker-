# Shipping Tracker

A lightweight bilingual (Khmer/English) shipping dashboard based on the supplied New Hope Cambodia PDF. It is a static website: no build step, backend, database, API key, or external dependency is required.

## Run locally

Open `index.html` in a modern browser, or serve the folder with any static file server. For example:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages

1. Create a GitHub repository and upload/push the contents of this folder to the repository's `main` branch. Keep `index.html`, `styles.css`, and `app.js` at the repository root.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
4. Wait for the Pages deployment to complete; GitHub will show the site URL in the Pages settings.

No Jekyll or package installation is needed. All paths are relative, so this also works when served from a GitHub Pages project subpath.

## Data and calculations

Records are saved in the current browser's `localStorage`; they do not sync between devices, browsers, or users. Clearing browser storage removes these records. The initial April 2026 rows are editable demonstration data based on the PDF layout and use a generic employee label. There is no preset employee list: type the employee's name in the form. Enter the number of 20 kg, 25 kg, and 30 kg bags; total tons are calculated automatically. USD incentive is calculated at 7% of the record's tons. A second save for the same employee and day replaces that record.

This app has no login or shared database. Do not use it as the sole copy of operational or payroll records.
